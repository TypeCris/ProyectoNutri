package com.mycompany.nutricion;

import Vistas.Login;

public class inicio {
    public static void main(String[] args) {
//        FormRoles objetoFormulario = new FormRoles();
//        objetoFormulario.setVisible(false);
      Login login = new Login();
        login.setVisible(true);
        
        
        
    }
    
}
