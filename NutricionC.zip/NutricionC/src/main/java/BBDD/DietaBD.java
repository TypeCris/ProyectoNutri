package BBDD;

import BBDD.ConexionBD;
import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashSet;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class DietaBD {

    int ID_dieta;
    String nombre;
    String descripcion;

    public int getID_dieta() {
        return ID_dieta;
    }

    public void setID_dieta(int ID_dieta) {
        this.ID_dieta = ID_dieta;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String InsertarDieta(JTextField paraNombre, JTextField paraDescripcion) {
        setNombre(paraNombre.getText());
        setDescripcion(paraDescripcion.getText());

        ConexionBD objetoConexion = new ConexionBD();

        String consulta = "INSERT INTO Dieta (nombre, descripcion) VALUES (?, ?)";
        try {
            CallableStatement cs = objetoConexion.estableceConection().prepareCall(consulta);
            cs.setString(1, getNombre());
            cs.setString(2, getDescripcion());
            cs.execute();
//            JOptionPane.showMessageDialog(null, "Se insertaron correctamente los datos");
            return "Dieta insertada correctamente";
        } catch (Exception e) {
//            JOptionPane.showMessageDialog(null, "No se ha logrado insertar");
            return ("No se ha logrado insertar " + e.getMessage());
        } 
    }

    public void MostrarDieta(JTable paraTablaTotalDieta) {
        ConexionBD objetoconexion = new ConexionBD();
        DefaultTableModel modelo = new DefaultTableModel();

        TableRowSorter<TableModel> OrdernarTabla = new TableRowSorter<TableModel>(modelo);
        paraTablaTotalDieta.setRowSorter(OrdernarTabla);

        String sql = "";
        modelo.addColumn("ID Dieta");
        modelo.addColumn("Nombre");
        modelo.addColumn("Descripcion");
        paraTablaTotalDieta.setModel(modelo);

        sql = "SELECT * FROM Dieta;";

        String[] datos = new String[8];
        Statement st;
        try {
            st = objetoconexion.estableceConection().createStatement();

            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                modelo.addRow(datos);
            }
            paraTablaTotalDieta.setModel(modelo);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "No se pudo mostrar las dietas, error: " + ex.toString());
        }

    }

    public void SeleccionarDieta(JTable paraTablaDieta, JTextField paraID, JTextField paraNombre, JTextField paraDescripcion) {
        try {
            int fila = paraTablaDieta.getSelectedRow();
            if (fila >= 0) {
                paraID.setText((paraTablaDieta.getValueAt(fila, 0).toString()));
                paraNombre.setText((paraTablaDieta.getValueAt(fila, 1).toString()));
                paraDescripcion.setText((paraTablaDieta.getValueAt(fila, 2).toString()));
            } else {
                JOptionPane.showMessageDialog(null, "Fila no seleccionada");
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error de seleccion, errror: " + ex.toString());

        }

    }

    public String ModificarDieta(JTextField paraID, JTextField paraNombre, JTextField paraDescripcion) {
        setID_dieta(Integer.parseInt(paraID.getText()));
        setNombre(paraNombre.getText());
        setDescripcion(paraDescripcion.getText());

        ConexionBD objetoConexion = new ConexionBD();

        String consulta = """
                          Update Dieta Set 
                          nombre = ?,
                          descripcion = ?
                          where ID_dieta = ?; """;
        try {
            CallableStatement cs = objetoConexion.estableceConection().prepareCall(consulta);
            cs.setString(1, getNombre());
            cs.setString(2, getDescripcion());
            cs.setInt(3, getID_dieta());
            cs.execute();
            return "Modificacion exitosa";
//            JOptionPane.showMessageDialog(null, "Modificacion exitosa");
        } catch (SQLException e) {
            return "No se modificó, error: "+ e.toString();
//            JOptionPane.showMessageDialog(null, "No se modificó, error: " + e.toString());

        }
    }

    public String EliminarDieta(JTextField paraID) {
        setID_dieta(Integer.parseInt(paraID.getText()));

        ConexionBD objetoConexion = new ConexionBD();

        String consulta = "DELETE FROM Dieta WHERE ID_dieta = ?";
        try {
            CallableStatement cs = objetoConexion.estableceConection().prepareCall(consulta);
            cs.setInt(1, getID_dieta());
            cs.execute();
            JOptionPane.showMessageDialog(null, "Se eliminó correcamente");
            return "Se eliminó correcamente";

        } catch (SQLException SQLE) {
            JOptionPane.showMessageDialog(null, "No se eliminó, error: " + SQLE.getMessage());
            return "No se eliminó, error: " + SQLE.getMessage();

        } catch (NumberFormatException NFE) {
            return "No se eliminó, error: " + NFE.getMessage();
        }
    }
}
