package BBDD;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class RolesBD {
    
    int ID_rol;
    String nombre;
    String descripcion;
    
    public int getID_rol() {
        return ID_rol;
    }

    public void setID_rol(int ID_rol) {
        this.ID_rol = ID_rol;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
    public String InsertarRol(JTextField paraNombre, JTextField paraDescripcion){
        
        setNombre(paraNombre.getText());
        setDescripcion(paraDescripcion.getText());
        
        ConexionBD objetoConexion = new ConexionBD();
        
        String consulta = "INSERT INTO ROLES (nombre,descripcion) VALUES (?,?)";
        try{
            CallableStatement cs = objetoConexion.estableceConection().prepareCall(consulta);
            cs.setString(1, getNombre());
            cs.setString(2, getDescripcion());
            cs.execute();
            JOptionPane.showMessageDialog(null, "Se inserto correctamente");
            return "Rol insertado correctamente";
        }catch (Exception ex){
            JOptionPane.showMessageDialog(null, "no se ha podido insertar");
            return ("No se ha logrado insertar" + ex.getMessage());
            
        }   
    }
   
    public void MostarRoles(JTable paraTablaTotalRoles){
        ConexionBD objetoconexion = new ConexionBD();
        DefaultTableModel modelo = new DefaultTableModel();
        
        TableRowSorter<TableModel> OrdenarTabla = new TableRowSorter<TableModel>(modelo);
        paraTablaTotalRoles.setRowSorter(OrdenarTabla);
        
        String sql = "";
        modelo.addColumn("ID Rol");
        modelo.addColumn("Nombre rol");
        modelo.addColumn("Descripcion");
        
        paraTablaTotalRoles.setModel(modelo);
        sql = "SELECT * FROM Roles;";
        
        String[] datos = new String[3];
        Statement st;
        
        try{
            st = objetoconexion.estableceConection().createStatement();
            ResultSet rs = st.executeQuery(sql);
            while(rs.next()){
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                modelo.addRow(datos);
            }
            paraTablaTotalRoles.setModel(modelo);
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, "No se pudo mostrar los roles "+ ex.toString());
            
        }
        
        
        
        
        
    }
    
    
}
