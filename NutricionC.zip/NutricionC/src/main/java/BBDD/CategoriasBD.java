package BBDD;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Set;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class CategoriasBD {

    int ID_Categoria;
    String nombre;
    String descripcion;

    public int getID_Categoria() {
        return ID_Categoria;
    }

    public void setID_Categoria(int ID_Categoria) {
        this.ID_Categoria = ID_Categoria;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String InsertarCategoria(JTextField paraNombre, JTextField paraDesc) {
        setNombre(paraNombre.getText());
        setDescripcion(paraDesc.getText());

        ConexionBD objetoConexion = new ConexionBD();

        String consulta = "INSERT INTO categorias(nombre,descripcion) VALUES (?,?);";
        try {
            CallableStatement cs = objetoConexion.conexionSinMensaje().prepareCall(consulta);
            cs.setString(1, getNombre());
            cs.setString(2, getDescripcion());
            cs.execute();
            JOptionPane.showMessageDialog(null, "Se inserto correctamente");
            return "Categoria insertada correctamente";

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "no se ha podido insertar");
            return ("No se ha logrado insertar" + ex.getMessage());
        }

    }

    public void MostrarCategorias(JTable paramTablaTotalCategorias) {
        ConexionBD objetoconexion = new ConexionBD();
        DefaultTableModel modelo = new DefaultTableModel();

        TableRowSorter<TableModel> OrdernarTabla = new TableRowSorter<TableModel>(modelo);
        paramTablaTotalCategorias.setRowSorter(OrdernarTabla);

        String sql = "";
        modelo.addColumn("ID Categoria");
        modelo.addColumn("Nombre");
        modelo.addColumn("Descripcion");
        paramTablaTotalCategorias.setModel(modelo);

        sql = "SELECT * FROM categorias;";

        String[] datos = new String[3];
        Statement st;
        try {
            st = objetoconexion.conexionSinMensaje().createStatement();

            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                modelo.addRow(datos);
            }
            paramTablaTotalCategorias.setModel(modelo);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "No se pudieron mostrar las categorias, error: " + ex.toString());
        }
    }

    public void SeleccionarCategoria(JTable paramTablaCategorias, JTextField paramID, JTextField paraNombre, JTextField paraDescripcion) {

        try {
            int fila = paramTablaCategorias.getSelectedRow();
            if (fila >= 0) {
                paramID.setText((paramTablaCategorias.getValueAt(fila, 0).toString()));
                paraNombre.setText((paramTablaCategorias.getValueAt(fila, 1).toString()));
                paraDescripcion.setText((paramTablaCategorias.getValueAt(fila, 2).toString()));
            } else {
                JOptionPane.showMessageDialog(null, "Fila no seleccionada");
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error de seleccion, errror: " + ex.toString());
        }
    }
    public void ModificarCategoria(JTextField paramID,JTextField paraNombre, JTextField paraDescripcion){
        setID_Categoria(Integer.parseInt(paramID.getText()));
        setNombre(paraNombre.getText());
        setDescripcion(paraDescripcion.getText());
        
        ConexionBD objetoConexion = new ConexionBD();
        
        String consulta = """
                          Update Categorias Set 
                          nombre = ?,
                          descripcion = ?,
                          where ID_categoria = ?; """;
        try{
            CallableStatement cs = objetoConexion.conexionSinMensaje().prepareCall(consulta);
            cs.setString(1, getNombre());
            cs.setString(2, getDescripcion());
            cs.setInt(3, getID_Categoria());
            cs.execute();
            
            JOptionPane.showMessageDialog(null, "Modificacion exitosa");            
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null,"No se modificó, error: "+e.toString());   
            
            
        }     
    }
    public String EliminarCategoria(JTextField paramID){
        setID_Categoria(Integer.parseInt(paramID.getText()));
        
        ConexionBD objetoConexion = new ConexionBD();

        String consulta = "DELETE FROM categorias WHERE ID_categoria = ?";
        try{
            CallableStatement cs = objetoConexion.conexionSinMensaje().prepareCall(consulta);
            cs.setInt(1, getID_Categoria());
            cs.execute();
            JOptionPane.showMessageDialog(null, "Se eliminó correcamente");
            return "Se eliminó correcamente";
            
        }catch(SQLException SQLE){
            JOptionPane.showMessageDialog(null, "No se eliminó, error: "+SQLE.getMessage());
            return "No se eliminó, error: " + SQLE.getMessage();
            
        }catch(NumberFormatException NFE){
            return "No se eliminó, error: " + NFE.getMessage();
        }
    }

}
