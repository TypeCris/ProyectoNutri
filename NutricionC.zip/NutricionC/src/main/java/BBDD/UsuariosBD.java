package BBDD;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class UsuariosBD {

    String nombre;
    String apellido;
    String email;
    String contrasenia;
    int id;
    int ID_rol;

    public int getID_rol() {
        return ID_rol;
    }

    public void setID_rol(int ID_rol) {
        this.ID_rol = ID_rol;
    }

    public String getContrasenia() {
        return contrasenia;
    }

    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String InsertarUsuario(JTextField paraNombre, JTextField paraApellido, JTextField paraEmail, JTextField paraContrasenia, JTextField paraID_Rol) {
        setNombre(paraNombre.getText());
        setApellido(paraApellido.getText());
        setEmail(paraEmail.getText());
        setID_rol(Integer.parseInt(paraID_Rol.getText()));
        setContrasenia(paraContrasenia.getText());

        ConexionBD objetoConexion = new ConexionBD();

        String consulta = ("INSERT INTO Usuarios (nombre ,apellido, email, contrasenia, ID_rol) VALUES(?,?,?,?,?)");

        try {
            CallableStatement cs = objetoConexion.conexionSinMensaje().prepareCall(consulta);
            cs.setString(1, getNombre());
            cs.setString(2, getApellido());
            cs.setString(3, getEmail());
            cs.setString(4, getContrasenia());
            cs.setInt(5, getID_rol());
            cs.execute();
//            JOptionPane.showMessageDialog(null, "Se inserto correctamente");
            return "Usuario insertado correctamente";
        } catch (Exception ex) {
//            JOptionPane.showMessageDialog(null, "no se ha podido insertar " + ex.getMessage());
            return ("No se ha logrado insertar" + ex.getMessage());

        }
    }

    public void MostrarUsuarios(JTable paramTablaTotalUsuarios) {
        ConexionBD objetoconexion = new ConexionBD();
        DefaultTableModel modelo = new DefaultTableModel();

        TableRowSorter<TableModel> OrdernarTabla = new TableRowSorter<TableModel>(modelo);
        paramTablaTotalUsuarios.setRowSorter(OrdernarTabla);

        String sql = "";
        modelo.addColumn("ID Usuario");
        modelo.addColumn("Nombre");
        modelo.addColumn("Apellido");
        modelo.addColumn("Email");
        modelo.addColumn("Contraseña");
        modelo.addColumn("ID Rol");

        paramTablaTotalUsuarios.setModel(modelo);

        sql = "SELECT * FROM Usuarios;";

        String[] datos = new String[6];
        Statement st;
        try {
            st = objetoconexion.conexionSinMensaje().createStatement();

            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                datos[3] = rs.getString(4);
                datos[4] = rs.getString(5);
                datos[5] = rs.getString(6);
                modelo.addRow(datos);
            }
            paramTablaTotalUsuarios.setModel(modelo);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "No se pudieron mostrar los Usuarios, error: " + ex.toString());
        }
    }

    public void SeleccionarUsuario(JTable paramTablaTotalUsuarios, JTextField paraId, JTextField paraNombre, JTextField paraApellido, JTextField paraEmail, JTextField paraID_rol, JTextField paraContrasenia) {
        try {
            int fila = paramTablaTotalUsuarios.getSelectedRow();
            if (fila >= 0) {
                paraId.setText((paramTablaTotalUsuarios.getValueAt(fila, 0).toString()));
                paraNombre.setText((paramTablaTotalUsuarios.getValueAt(fila, 1).toString()));
                paraApellido.setText((paramTablaTotalUsuarios.getValueAt(fila, 2).toString()));
                paraEmail.setText((paramTablaTotalUsuarios.getValueAt(fila, 3).toString()));
                paraID_rol.setText((paramTablaTotalUsuarios.getValueAt(fila, 4).toString()));
                paraContrasenia.setText((paramTablaTotalUsuarios.getValueAt(fila, 5).toString()));
            } else {
                JOptionPane.showMessageDialog(null, "No se pudieron mostrar los Usuarios");
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "No se pudieron mostrar los Usuarios, error: " + ex.toString());
        }
    }

    public String ModificarUsuario(JTextField paraNombre, JTextField paraApellido, JTextField paraEmail, JTextField paramContra, JTextField paraId, JTextField paraID_rol) {

        setId(Integer.parseInt(paraId.getText()));
        setNombre(paraNombre.getText());
        setApellido(paraApellido.getText());
        setEmail(paraEmail.getText());
        setContrasenia(paramContra.getText());
        setID_rol(Integer.parseInt(paraID_rol.getText()));

        ConexionBD objetoconexion = new ConexionBD();
        String consulta = """
                          Update Usuarios set 
                          nombre = ?, 
                          apellido = ?, 
                          email = ?,
                          contrasenia = ?,
                          ID_rol = ? 
                          where ID_usuario=?;""";
        try {
            CallableStatement ps = objetoconexion.estableceConection().prepareCall(consulta);
            try {
                ps.setString(1, getNombre());
                ps.setString(2, getApellido());
                ps.setString(3, (String) getEmail());
                ps.setString(4, getContrasenia());
                ps.setInt(5, getID_rol());
                ps.setInt(6, getId());

            }catch(SQLException EXC){
                JOptionPane.showMessageDialog(null, "ERRROR:" + EXC.getMessage());
            }

            ps.execute();
            return "Se han guardados los cambios: ";
        } catch (Exception ex) {
            return "No se pudieron mostrar, error: " + ex.toString();
        }
    }

    public String EliminarUsuario(JTextField paraId) {
        setId(Integer.parseInt(paraId.getText()));

        ConexionBD objetoconexion = new ConexionBD();
        String consulta = "delete from Usuarios where usuarios.ID_usuario = ?";
        try {
            CallableStatement cs = objetoconexion.conexionSinMensaje().prepareCall(consulta);
            cs.setInt(1, getId());
            cs.execute();
            return "Se ha eliminado el usuario";
//            JOptionPane.showMessageDialog(null, "Se han guardados los cambios");
        } catch (Exception ex) {
            return "No se puedo eliminar, error: " + ex.toString();
//            JOptionPane.showMessageDialog(null, "No se puedo eliminar, error: " + ex.toString());
        }
    }
}
