package BBDD;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class PlanUsuarioBD {

    int ID_plan;
    int ID_usuario;
    int ID_dieta;
    String fecha_inicio;
    String fecha_fin;

    public int getID_plan() {
        return ID_plan;
    }

    public void setID_plan(int ID_plan) {
        this.ID_plan = ID_plan;
    }

    public int getID_usuario() {
        return ID_usuario;
    }

    public void setID_usuario(int ID_usuario) {
        this.ID_usuario = ID_usuario;
    }

    public int getID_dieta() {
        return ID_dieta;
    }

    public void setID_dieta(int ID_dieta) {
        this.ID_dieta = ID_dieta;
    }

    public String getFechaInicio() {
        return fecha_inicio;
    }

    public void setFechaInicio(String fecha_inicio) {
        this.fecha_inicio = fecha_inicio;
    }

    public String getFechaFin() {
        return fecha_fin;
    }

    public void setFechaFin(String fecha_fin) {
        this.fecha_fin = fecha_fin;
    }

    public String InsertarPlan(JTextField paraID_usuario, JTextField paraID_dieta, JTextField paraFechaInicio, JTextField paraFechaFin) {
        setID_usuario(Integer.parseInt(paraID_usuario.getText()));
        setID_dieta(Integer.parseInt(paraID_dieta.getText()));
        setFechaInicio(paraFechaInicio.getText());
        setFechaFin(paraFechaFin.getText());

        ConexionBD objetoConexion = new ConexionBD();

        String consulta = "INSERT INTO Plan_Usuario (ID_usuario, ID_dieta, fecha_inicio, fecha_fin) VALUES (?, ?, ?, ?)";
        try {
            CallableStatement cs = objetoConexion.estableceConection().prepareCall(consulta);
            cs.setInt(1, getID_usuario());
            cs.setInt(2, getID_dieta());
            cs.setString(3, getFechaInicio());
            cs.setString(4, getFechaFin());
            cs.execute();
//            JOptionPane.showMessageDialog(null, "Se insertaron correctamente los datos");
            return "Plan insertado correctamente";
        } catch (Exception e) {
//            JOptionPane.showMessageDialog(null, "No se ha logrado insertar");
            return ("No se ha logrado insertar " + e.getMessage());
        }
    }

    public void MostrarPlan(JTable paraTablaTotalPlan) {
        ConexionBD objetoconexion = new ConexionBD();
        DefaultTableModel modelo = new DefaultTableModel();

        TableRowSorter<TableModel> OrdernarTabla = new TableRowSorter<TableModel>(modelo);
        paraTablaTotalPlan.setRowSorter(OrdernarTabla);

        String sql = "";
        modelo.addColumn("ID Plan");
        modelo.addColumn("ID Usuario");
        modelo.addColumn("ID Dieta");
        modelo.addColumn("Fecha Inicio");
        modelo.addColumn("Fecha Fin");
        paraTablaTotalPlan.setModel(modelo);

        sql = "SELECT * FROM Plan_Usuario;";

        String[] datos = new String[8];
        Statement st;
        try {
            st = objetoconexion.estableceConection().createStatement();

            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                datos[3] = rs.getString(4);
                datos[4] = rs.getString(5);
                modelo.addRow(datos);
            }
            paraTablaTotalPlan.setModel(modelo);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "No se pudo mostrar los planes de usuarios, error: " + ex.toString());
        }

    }

    public void SeleccionarPlan(JTable paraTablaPlan, JTextField paraID_plan, JTextField paraID_usuario, JTextField paraID_dieta, JTextField paraFechaInicio, JTextField paraFechaFin) {
        try {
            int fila = paraTablaPlan.getSelectedRow();
            if (fila >= 0) {
                paraID_plan.setText((paraTablaPlan.getValueAt(fila, 0).toString()));
                paraID_usuario.setText((paraTablaPlan.getValueAt(fila, 1).toString()));
                paraID_dieta.setText((paraTablaPlan.getValueAt(fila, 2).toString()));
                paraFechaInicio.setText((paraTablaPlan.getValueAt(fila, 3).toString()));
                paraFechaFin.setText((paraTablaPlan.getValueAt(fila, 4).toString()));
            } else {
                JOptionPane.showMessageDialog(null, "Fila no seleccionada");
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error de seleccion, errror: " + ex.toString());

        }

    }

    public void ModificarPlan(JTextField paraID_plan, JTextField paraID_usuario, JTextField paraID_dieta, JTextField paraFechaInicio, JTextField paraFechaFin) {
        setID_plan(Integer.parseInt(paraID_plan.getText()));
        setID_usuario(Integer.parseInt(paraID_usuario.getText()));
        setID_dieta(Integer.parseInt(paraID_dieta.getText()));
        setFechaInicio(paraFechaInicio.getText());
        setFechaFin(paraFechaFin.getText());

        ConexionBD objetoConexion = new ConexionBD();

        String consulta = """
                          Update Plan_Usuario Set 
                          ID_usuario = ?,
                          ID_dieta = ?,
                          fecha_inicio = ?,
                          fecha_fin = ?,
                          where ID_plan = ?; """;
        try {
            CallableStatement cs = objetoConexion.estableceConection().prepareCall(consulta);
            cs.setInt(1, getID_usuario());
            cs.setInt(2, getID_dieta());
            cs.setString(3, getFechaInicio());
            cs.setString(4, getFechaFin());
            cs.setInt(5, getID_plan());
            cs.execute();

            JOptionPane.showMessageDialog(null, "Modificacion exitosa");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se modificó, error: " + e.toString());

        }
    }

    public String EliminarPlan(JTextField paraID) {
        setID_plan(Integer.parseInt(paraID.getText()));

        ConexionBD objetoConexion = new ConexionBD();

        String consulta = "DELETE FROM PlanUsuario WHERE ID_plan = ?";
        try {
            CallableStatement cs = objetoConexion.estableceConection().prepareCall(consulta);
            cs.setInt(1, getID_plan());
            cs.execute();
//            JOptionPane.showMessageDialog(null, "Se eliminó correcamente");
            return "Se eliminó correcamente";

        } catch (SQLException SQLE) {
//            JOptionPane.showMessageDialog(null, "No se eliminó, error: " + SQLE.getMessage());
            return "No se eliminó, error: " + SQLE.getMessage();

        } catch (NumberFormatException NFE) {
            return "No se eliminó, error: " + NFE.getMessage();
        }
    }
}
