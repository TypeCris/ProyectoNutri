package BBDD;

import java.sql.CallableStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

public class AlimentosBD {

    int ID_alimento;
    String nombre;
    String descripcion;
    int ID_Categoria;
    double calorias;
    double proteinas;
    double carbohidratos;
    double grasas;

    public int getID_alimento() {
        return ID_alimento;
    }

    public void setID_alimento(int ID_alimento) {
        this.ID_alimento = ID_alimento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getID_Categoria() {
        return ID_Categoria;
    }

    public void setID_Categoria(int ID_Categoria) {
        this.ID_Categoria = ID_Categoria;
    }

    public double getCalorias() {
        return calorias;
    }

    public void setCalorias(double calorias) {
        this.calorias = calorias;
    }

    public double getProteinas() {
        return proteinas;
    }

    public void setProteinas(double proteinas) {
        this.proteinas = proteinas;
    }

    public double getCarbohidratos() {
        return carbohidratos;
    }

    public void setCarbohidratos(double carbohidratos) {
        this.carbohidratos = carbohidratos;
    }

    public double getGrasas() {
        return grasas;
    }

    public void setGrasas(double grasas) {
        this.grasas = grasas;
    }

    public String InsertarAlimento(JTextField paraNombre, JTextField paraDescripcion, JTextField paraID_Categoria,
            JTextField paraCalorias, JTextField paraProteinas, JTextField paraCarbohidratos, JTextField paraGrasas) {

        setNombre(paraNombre.getText());
        setDescripcion(paraDescripcion.getText());
        setID_Categoria(Integer.parseInt(paraID_Categoria.getText()));
        setCalorias(Double.parseDouble(paraCalorias.getText()));
        setProteinas(Double.parseDouble(paraProteinas.getText()));
        setCarbohidratos(Double.parseDouble(paraCarbohidratos.getText()));
        setGrasas(Double.parseDouble(paraGrasas.getText()));

        ConexionBD objetoConexion = new ConexionBD();

        String consulta = "INSERT INTO Alimentos (nombre,descripcion,ID_categoria,calorias,proteinas,carbohidratos,grasas) VALUES(?,?,?,?,?,?,?)";
        try {
            CallableStatement cs = objetoConexion.conexionSinMensaje().prepareCall(consulta);
            cs.setString(1, getNombre());
            cs.setString(2, getDescripcion());
            cs.setInt(3, getID_Categoria());
            cs.setDouble(4, getCalorias());
            cs.setDouble(5, getProteinas());
            cs.setDouble(6, getCarbohidratos());
            cs.setDouble(7, getGrasas());
            cs.execute();
//            JOptionPane.showMessageDialog(null, "Se inserto correctamente");
            return "Alimento insertado correctamente";
        } catch (Exception ex) {
//            JOptionPane.showMessageDialog(null, "no se ha podido insertar");
            return ("No se ha logrado insertar" + ex.getMessage());

        }
    }

    public void MostrarAlimentos(JTable paramTablaTotalAlimentos) {
        ConexionBD objetoconexion = new ConexionBD();
        DefaultTableModel modelo = new DefaultTableModel();

        TableRowSorter<TableModel> OrdernarTabla = new TableRowSorter<TableModel>(modelo);
        paramTablaTotalAlimentos.setRowSorter(OrdernarTabla);

        String sql = "";
        modelo.addColumn("ID Alimento");
        modelo.addColumn("Nombre");
        modelo.addColumn("Descripcion");
        modelo.addColumn("ID_categoria");
        modelo.addColumn("Calorias");
        modelo.addColumn("Proteinas");
        modelo.addColumn("Carbohidratos");
        modelo.addColumn("Grasas");
        paramTablaTotalAlimentos.setModel(modelo);

        sql = "SELECT * FROM Alimentos;";

        String[] datos = new String[8];
        Statement st;
        try {
            st = objetoconexion.conexionSinMensaje().createStatement();

            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                datos[3] = rs.getString(4);
                datos[4] = rs.getString(5);
                datos[5] = rs.getString(6);
                datos[6] = rs.getString(7);
                datos[7] = rs.getString(8);
                modelo.addRow(datos);
            }
            paramTablaTotalAlimentos.setModel(modelo);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "No se pudieron mostrar los Alimentos, error: " + ex.toString());
        }

    }

    public void SeleccionarAlimento(JTable paramTablaAlimentos, JTextField paramID, JTextField paraNombre, JTextField paraDescripcion, JTextField paraID_Categoria,
            JTextField paramCalorias, JTextField paramProteinas, JTextField paramCarbohidratos, JTextField paramGrasas) {
        try {
            int fila = paramTablaAlimentos.getSelectedRow();
            if (fila >= 0) {
                paramID.setText((paramTablaAlimentos.getValueAt(fila, 0).toString()));
                paraNombre.setText((paramTablaAlimentos.getValueAt(fila, 1).toString()));
                paraDescripcion.setText((paramTablaAlimentos.getValueAt(fila, 2).toString()));
                paraID_Categoria.setText((paramTablaAlimentos.getValueAt(fila, 3).toString()));
                paramCalorias.setText((paramTablaAlimentos.getValueAt(fila, 4).toString()));
                paramProteinas.setText((paramTablaAlimentos.getValueAt(fila, 5).toString()));
                paramCarbohidratos.setText((paramTablaAlimentos.getValueAt(fila, 6).toString()));
                paramGrasas.setText((paramTablaAlimentos.getValueAt(fila, 7).toString()));
            } else {
                JOptionPane.showMessageDialog(null, "Fila no seleccionada");
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Error de seleccion, errror: " + ex.toString());

        }

    }

    public String ModificarAlimento(JTextField paramID, JTextField paraNombre, JTextField paraDescripcion, JTextField paraID_Categoria,
            JTextField paramCalorias, JTextField paramProteinas, JTextField paramCarbohidratos, JTextField paramGrasas) {
        setID_alimento(Integer.parseInt(paramID.getText()));
        setNombre(paraNombre.getText());
        setDescripcion(paraDescripcion.getText());
        setID_Categoria(Integer.parseInt(paraID_Categoria.getText()));
        setCalorias(Double.parseDouble(paramCalorias.getText()));
        setProteinas(Double.parseDouble(paramProteinas.getText()));
        setCarbohidratos(Double.parseDouble(paramCarbohidratos.getText()));
        setGrasas(Double.parseDouble(paramGrasas.getText()));

        ConexionBD objetoConexion = new ConexionBD();

        String consulta = """
                          Update Alimentos Set 
                          nombre = ?,
                          descripcion = ?,
                          ID_categoria = ?,
                          calorias = ?,
                          proteinas = ?,
                          carbohidratos = ?,
                          grasas = ?
                          where ID_alimento = ?; """;
        try {
            CallableStatement cs = objetoConexion.estableceConection().prepareCall(consulta);
            cs.setString(1, getNombre());
            cs.setString(2, getDescripcion());
            cs.setInt(3, getID_Categoria());
            cs.setDouble(4, getCalorias());
            cs.setDouble(5, getProteinas());
            cs.setDouble(6, getCarbohidratos());
            cs.setDouble(7, getGrasas());
            cs.setInt(8, getID_alimento());
            cs.execute();
            return "Modificacion exitosa";
        } catch (SQLException e) {
            return "Modificacion fallida, error: "+ e.getMessage();
//            JOptionPane.showMessageDialog(null, "No se modificó, error: " + e.toString());

        }
    }

    public String EliminarAlimento(JTextField paramID) {
        setID_alimento(Integer.parseInt(paramID.getText()));

        ConexionBD objetoConexion = new ConexionBD();

        String consulta = "DELETE FROM Alimentos WHERE ID_alimento = ?";
        try {
            CallableStatement cs = objetoConexion.conexionSinMensaje().prepareCall(consulta);
            cs.setInt(1, getID_alimento());
            cs.execute();
            //JOptionPane.showMessageDialog(null, "Se eliminó correcamente");
            return "Se eliminó correcamente";

        } catch (SQLException SQLE) {
            //JOptionPane.showMessageDialog(null, "No se eliminó, error: " + SQLE.getMessage());
            return "No se eliminó, error: " + SQLE.getMessage();

        } catch (NumberFormatException NFE) {
            return "No se eliminó, error: " + NFE.getMessage();
        }
    }

}
