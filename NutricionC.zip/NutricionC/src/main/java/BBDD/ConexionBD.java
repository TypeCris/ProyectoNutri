package BBDD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;

public class ConexionBD {

    Connection conectar = null;
    String usuario = "root";
    String contrasenna = "admin123";
    String bd = "nutricion_bbdd";
    String ip = "localhost";
    String puerto = "3306";

    String cadena = "jdbc:mysql://" + ip + ":" + puerto + "/" + bd;

    public Connection estableceConection() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conectar = DriverManager.getConnection(cadena, usuario, contrasenna);
            //JOptionPane.showMessageDialog(null, "La conexion se ha realizado con exito");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Eror al conectarse a la base de datos " + e.toString());
        }
        return conectar;
    }

    public Connection conexionSinMensaje(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conectar = DriverManager.getConnection(cadena, usuario, contrasenna);
            System.out.println("Conectado correctamente");
        } catch (Exception e) {
            System.out.println("ERROR: "+e.getMessage());
        }
        return conectar;
    }

    public PreparedStatement prepareStatement(String consulta) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}

